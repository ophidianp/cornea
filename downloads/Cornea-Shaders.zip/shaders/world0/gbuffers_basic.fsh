#version 430 compatibility
#define WORLD_OVERWORLD
#define FRAGMENT_SHADER
#define PROGRAM_BASIC
#include "/program/gbuffers_solid.glsl"
