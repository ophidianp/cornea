#version 430 compatibility
#define WORLD_NETHER
#define VERTEX_SHADER
#define PROGRAM_WATER
#include "/program/gbuffers_translucent.glsl"
