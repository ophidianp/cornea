#version 430 compatibility
#define WORLD_NETHER
#define VERTEX_SHADER
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
