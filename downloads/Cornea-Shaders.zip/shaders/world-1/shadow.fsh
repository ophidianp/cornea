#version 430 compatibility
#define WORLD_NETHER
#define FRAGMENT_SHADER
#define PROGRAM_SHADOW
#include "/program/shadow.glsl"
