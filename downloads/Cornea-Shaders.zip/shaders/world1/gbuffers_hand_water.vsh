#version 430 compatibility
#define WORLD_END
#define VERTEX_SHADER
#define PROGRAM_HAND_WATER
#include "/program/gbuffers_translucent.glsl"
