#version 430 compatibility
#define WORLD_END
#define FRAGMENT_SHADER
#define PROGRAM_HAND
#include "/program/gbuffers_solid.glsl"
