#version 430 compatibility
#define WORLD_END
#define VERTEX_SHADER
#define PROGRAM_BASIC
#include "/program/gbuffers_solid.glsl"
