#version 430 compatibility
#define WORLD_END
#define VERTEX_SHADER
#define PROGRAM_PARTICLES
#include "/program/gbuffers_translucent.glsl"
