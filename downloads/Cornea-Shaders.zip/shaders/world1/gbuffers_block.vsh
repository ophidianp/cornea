#version 430 compatibility
#define WORLD_END
#define VERTEX_SHADER
#define PROGRAM_BLOCK
#include "/program/gbuffers_solid.glsl"
